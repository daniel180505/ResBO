package s12.proyec.restaurantee;

import Vista.VistaLogin;


public class Restaurantee {
    public static void main(String[] args) {
        new VistaLogin();
    }
}
